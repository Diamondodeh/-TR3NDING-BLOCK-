import { Search, SlidersHorizontal, X } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

// Define genres and years locally since we no longer use mock data
const genres = ['Action', 'Anime', 'Horror', 'Romance', 'Sci-Fi', 'Adventure', 'Drama', 'Thriller', 'Fantasy', 'Mystery'];
const years = [2026, 2025, 2024, 2023, 2022, 2021, 2020];

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onFilterChange?: (filters: SearchFilters) => void;
  placeholder?: string;
}

export interface SearchFilters {
  genre: string | null;
  year: number | null;
  rating: number | null;
}

export const SearchBar = ({ 
  value, 
  onChange, 
  onFilterChange,
  placeholder = "SEARCH CATEGORIES..." 
}: SearchBarProps) => {
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    genre: null,
    year: null,
    rating: null,
  });

  const handleFilterChange = (key: keyof SearchFilters, val: string | number | null) => {
    const newFilters = { ...filters, [key]: val };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const clearFilters = () => {
    const cleared = { genre: null, year: null, rating: null };
    setFilters(cleared);
    onFilterChange?.(cleared);
  };

  const hasActiveFilters = filters.genre || filters.year || filters.rating;

  return (
    <div className="px-4 py-3">
      <div className="relative">
        <Search 
          size={18} 
          className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" 
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="search-input"
        />
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={cn(
            'absolute right-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition-colors',
            showFilters || hasActiveFilters 
              ? 'bg-primary text-primary-foreground' 
              : 'text-muted-foreground hover:text-foreground'
          )}
        >
          <SlidersHorizontal size={18} />
        </button>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="mt-3 p-4 glass-card animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-semibold text-foreground">Filters</span>
            {hasActiveFilters && (
              <button 
                onClick={clearFilters}
                className="text-xs text-primary flex items-center gap-1"
              >
                <X size={12} />
                Clear all
              </button>
            )}
          </div>

          {/* Genre Filter */}
          <div className="mb-3">
            <label className="text-xs text-muted-foreground mb-2 block">Genre</label>
            <div className="flex flex-wrap gap-2">
              {genres.slice(0, 6).map((genre) => (
                <button
                  key={genre}
                  onClick={() => handleFilterChange('genre', filters.genre === genre ? null : genre)}
                  className={cn(
                    'category-pill text-xs',
                    filters.genre === genre && 'active'
                  )}
                >
                  {genre}
                </button>
              ))}
            </div>
          </div>

          {/* Year Filter */}
          <div className="mb-3">
            <label className="text-xs text-muted-foreground mb-2 block">Release Year</label>
            <div className="flex flex-wrap gap-2">
              {years.map((year) => (
                <button
                  key={year}
                  onClick={() => handleFilterChange('year', filters.year === year ? null : year)}
                  className={cn(
                    'category-pill text-xs',
                    filters.year === year && 'active'
                  )}
                >
                  {year}
                </button>
              ))}
            </div>
          </div>

          {/* Rating Filter */}
          <div>
            <label className="text-xs text-muted-foreground mb-2 block">Minimum Rating</label>
            <div className="flex gap-2">
              {[7, 8, 9].map((rating) => (
                <button
                  key={rating}
                  onClick={() => handleFilterChange('rating', filters.rating === rating ? null : rating)}
                  className={cn(
                    'category-pill text-xs',
                    filters.rating === rating && 'active'
                  )}
                >
                  {rating}+ ★
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
