import { Crown } from 'lucide-react';

export const PremiumBanner = () => {
  return (
    <div className="fixed bottom-16 left-0 right-0 z-40 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 border-t border-b border-primary/30 px-4 py-2">
      <div className="flex items-center justify-center gap-2">
        <Crown size={14} className="text-primary" />
        <span className="text-xs text-primary font-semibold tracking-wider">
          SPONSORED CONTENT PROVIDER
        </span>
        <span className="px-2 py-0.5 bg-primary text-primary-foreground text-xs font-bold rounded">
          PREMIUM
        </span>
      </div>
    </div>
  );
};
