import { useState, useEffect, useCallback } from 'react';
import { Search, X, Film, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

const TMDB_API_KEY = '76d5976bcd89fc95d5f49c67e6af7f16';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';

interface TMDBMovie {
  id: number;
  title: string;
  name?: string; // For TV shows
  poster_path: string | null;
  overview: string;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  media_type?: string;
}

interface TMDBSearchProps {
  onSelectMovie?: (movie: {
    title: string;
    description: string;
    posterUrl: string;
    releaseYear: number;
    rating: number;
  }) => void;
  placeholder?: string;
  className?: string;
}

export const TMDBSearch = ({ 
  onSelectMovie, 
  placeholder = "Search movies & TV shows...",
  className 
}: TMDBSearchProps) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<TMDBMovie[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const searchTMDB = useCallback(async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(
        `${TMDB_BASE_URL}/search/multi?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(searchQuery)}&include_adult=false`
      );
      const data = await response.json();
      
      // Filter to only movies and TV shows
      const filteredResults = (data.results || [])
        .filter((item: TMDBMovie) => 
          item.media_type === 'movie' || item.media_type === 'tv'
        )
        .slice(0, 10);
      
      setResults(filteredResults);
    } catch (error) {
      console.error('TMDB search error:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query) {
        searchTMDB(query);
      } else {
        setResults([]);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query, searchTMDB]);

  const handleSelect = (movie: TMDBMovie) => {
    const title = movie.title || movie.name || '';
    const releaseDate = movie.release_date || movie.first_air_date || '';
    const releaseYear = releaseDate ? parseInt(releaseDate.split('-')[0]) : new Date().getFullYear();
    
    onSelectMovie?.({
      title,
      description: movie.overview || '',
      posterUrl: movie.poster_path ? `${TMDB_IMAGE_BASE}${movie.poster_path}` : '',
      releaseYear,
      rating: Math.round(movie.vote_average * 10) / 10,
    });

    setQuery('');
    setResults([]);
    setShowResults(false);
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
  };

  return (
    <div className={cn("relative", className)}>
      {/* Search Input */}
      <div className="relative">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowResults(true);
          }}
          onFocus={() => setShowResults(true)}
          placeholder={placeholder}
          className="pl-11 pr-10 bg-secondary"
        />
        {query && (
          <button
            onClick={clearSearch}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-background/50"
          >
            <X size={16} className="text-muted-foreground" />
          </button>
        )}
        {isLoading && (
          <Loader2 size={16} className="absolute right-10 top-1/2 -translate-y-1/2 animate-spin text-primary" />
        )}
      </div>

      {/* Results Dropdown */}
      {showResults && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 max-h-80 overflow-y-auto bg-background border border-border rounded-xl shadow-xl z-50">
          {results.map((movie) => (
            <button
              key={`${movie.media_type}-${movie.id}`}
              onClick={() => handleSelect(movie)}
              className="w-full p-3 flex gap-3 hover:bg-secondary/50 transition-colors border-b border-border/50 last:border-b-0"
            >
              {/* Poster */}
              <div className="w-12 h-18 rounded-lg bg-secondary overflow-hidden flex-shrink-0">
                {movie.poster_path ? (
                  <img 
                    src={`${TMDB_IMAGE_BASE}${movie.poster_path}`}
                    alt={movie.title || movie.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Film size={16} className="text-muted-foreground" />
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 text-left min-w-0">
                <p className="font-medium text-foreground truncate">
                  {movie.title || movie.name}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                  <span className="capitalize px-1.5 py-0.5 bg-primary/20 text-primary rounded">
                    {movie.media_type === 'tv' ? 'TV' : 'Movie'}
                  </span>
                  {(movie.release_date || movie.first_air_date) && (
                    <span>
                      {(movie.release_date || movie.first_air_date)?.split('-')[0]}
                    </span>
                  )}
                  {movie.vote_average > 0 && (
                    <span className="text-primary">★ {movie.vote_average.toFixed(1)}</span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                  {movie.overview}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Click outside to close */}
      {showResults && (
        <div 
          className="fixed inset-0 z-40"
          onClick={() => setShowResults(false)}
        />
      )}
    </div>
  );
};
