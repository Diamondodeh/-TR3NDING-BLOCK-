import { Header } from './Header';
import { BottomNav } from './BottomNav';

interface LayoutProps {
  children: React.ReactNode;
  showHeader?: boolean;
  showNav?: boolean;
}

export const Layout = ({ children, showHeader = true, showNav = true }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-background w-full max-w-screen-2xl mx-auto">
      {showHeader && <Header />}
      <main className={`
        ${showHeader ? 'pt-16' : ''} 
        ${showNav ? 'pb-20 lg:pb-4' : ''}
      `}>
        {children}
      </main>
      {showNav && <BottomNav />}
    </div>
  );
};
