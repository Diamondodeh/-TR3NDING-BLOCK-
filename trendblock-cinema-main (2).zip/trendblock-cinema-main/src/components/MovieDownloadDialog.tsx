import { useState } from 'react';
import { Download, X, Timer } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QualityOption {
  value: string;
  label: string;
  size: string;
  adDuration: number;
}

interface MovieDownloadDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onDownload: (quality: string) => void;
  movieTitle: string;
  duration?: string;
}

const QUALITY_OPTIONS: QualityOption[] = [
  { value: '360p', label: '360P', size: '~250 MB', adDuration: 3 },
  { value: '480p', label: '480P', size: '~500 MB', adDuration: 10 },
  { value: '720p', label: '720P', size: '~800 MB', adDuration: 10 },
  { value: '1080p', label: '1080P', size: '~1.5 GB', adDuration: 10 },
];

export const MovieDownloadDialog = ({
  isOpen,
  onClose,
  onDownload,
  movieTitle,
  duration = '2:00:00',
}: MovieDownloadDialogProps) => {
  const [showAd, setShowAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);
  const [selectedQuality, setSelectedQuality] = useState<string>('');

  const handleQualitySelect = (quality: string) => {
    const option = QUALITY_OPTIONS.find(q => q.value === quality);
    if (!option) return;

    setSelectedQuality(quality);
    setShowAd(true);
    setAdCountdown(option.adDuration);

    const interval = setInterval(() => {
      setAdCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setShowAd(false);
          onDownload(quality);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  if (!isOpen) return null;

  if (showAd) {
    return (
      <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center animate-fade-in">
        <div className="text-center px-6 max-w-sm">
          {/* Ad Placeholder */}
          <div className="w-full aspect-video bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl border border-primary/30 flex items-center justify-center mb-6">
            <div className="text-center">
              <Timer size={40} className="text-primary mx-auto mb-2 animate-pulse" />
              <p className="text-sm text-muted-foreground">Advertisement</p>
            </div>
          </div>

          {/* Countdown */}
          <div className="flex items-center justify-center gap-2 text-primary">
            <span className="text-4xl font-display gold-glow">{adCountdown}</span>
            <span className="text-sm">seconds remaining</span>
          </div>
          
          <p className="text-xs text-muted-foreground mt-4">
            Your download will start automatically...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div>
          <h2 className="font-display text-xl text-foreground">Resource</h2>
          <p className="text-xs text-muted-foreground">Select quality to download</p>
        </div>
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={20} className="text-foreground" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Quality Options */}
        <div className="space-y-3">
          {QUALITY_OPTIONS.map((option) => (
            <button
              key={option.value}
              onClick={() => handleQualitySelect(option.value)}
              className="w-full glass-card p-4 flex items-center justify-between transition-all hover:border-primary/50 hover:bg-primary/5"
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  'w-12 h-12 rounded-lg flex items-center justify-center',
                  option.value === '1080p' 
                    ? 'bg-primary/20' 
                    : option.value === '720p'
                      ? 'bg-blue-500/20'
                      : option.value === '480p'
                        ? 'bg-green-500/20'
                        : 'bg-secondary'
                )}>
                  <span className={cn(
                    'text-xs font-bold',
                    option.value === '1080p' 
                      ? 'text-primary' 
                      : option.value === '720p'
                        ? 'text-blue-400'
                        : option.value === '480p'
                          ? 'text-green-400'
                          : 'text-muted-foreground'
                  )}>
                    {option.label}
                  </span>
                </div>
                <div className="text-left">
                  <p className="font-medium text-foreground">
                    {option.label} {movieTitle}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {option.size} · {duration}
                  </p>
                </div>
              </div>
              
              <Download size={20} className="text-primary" />
            </button>
          ))}
        </div>

        {/* Info Box */}
        <div className="mt-6 p-4 rounded-lg bg-secondary/50 border border-border">
          <p className="text-xs text-muted-foreground text-center">
            360p: 3 second ad | 480p-1080p: 10 second ad
          </p>
        </div>
      </div>
    </div>
  );
};
