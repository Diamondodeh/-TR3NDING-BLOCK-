import { X, FileText, ScrollText } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface PrivacyPolicyDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyDialog = ({ isOpen, onClose }: PrivacyPolicyDialogProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center animate-fade-in">
      <div className="w-full h-full max-w-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <FileText size={24} className="text-primary" />
            <h2 className="font-display text-xl text-foreground">PRIVACY POLICY</h2>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
          >
            <X size={20} className="text-foreground" />
          </button>
        </div>

        {/* Content */}
        <ScrollArea className="flex-1 px-4">
          <div className="py-6 space-y-6">
            <div className="text-center mb-8">
              <h1 className="font-display text-2xl gold-gradient-text mb-2">
                Privacy Policy for TR3NDING BLOCK
              </h1>
              <p className="text-sm text-muted-foreground">Last Updated: January 29, 2026</p>
            </div>

            {/* Section 1 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">1</span>
                Introduction
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Welcome to TR3NDING BLOCK. We respect your privacy and are committed to protecting your personal data. This Privacy Policy will inform you as to how we look after your personal data when you visit our application and tell you about your privacy rights and how the law protects you.
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                It is important that you read this Privacy Policy together with any other privacy notice or fair processing notice we may provide on specific occasions when we are collecting or processing personal data about you so that you are fully aware of how and why we are using your data.
              </p>
            </section>

            {/* Section 2 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">2</span>
                The Data We Collect About You
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Personal data, or personal information, means any information about an individual from which that person can be identified. We may collect, use, store, and transfer different kinds of personal data about you which we have grouped together as follows:
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 pl-4">
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Identity Data:</strong> Includes first name, last name, username or similar identifier, and date of birth.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Contact Data:</strong> Includes email address and telephone numbers.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Financial Data:</strong> If applicable, includes payment card details and blockchain wallet addresses.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Transaction Data:</strong> Includes details about payments to and from you and other details of products and services you have purchased from us.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Technical Data:</strong> Includes internet protocol (IP) address, your login data, browser type and version, time zone setting and location, browser plug-in types and versions, operating system and platform, and other technology on the devices you use to access this app.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Usage Data:</strong> Includes information about how you use our app, products, and services.</span>
                </li>
              </ul>
            </section>

            {/* Section 3 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">3</span>
                How Is Your Personal Data Collected?
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We use different methods to collect data from and about you including through:
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 pl-4">
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Direct interactions:</strong> You may give us your Identity, Contact, and Financial Data by filling in forms or by corresponding with us by post, phone, email, or otherwise.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Automated technologies or interactions:</strong> As you interact with our app, we may automatically collect Technical Data about your equipment, browsing actions, and patterns.</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary">•</span>
                  <span><strong className="text-foreground">Third parties or publicly available sources:</strong> We may receive personal data about you from various third parties such as analytics providers (like Google), advertising networks, and search information providers.</span>
                </li>
              </ul>
            </section>

            {/* Section 4 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">4</span>
                How We Use Your Personal Data
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 pl-4">
                <li className="flex gap-2"><span className="text-primary">•</span><span>To register you as a new user.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>To process and deliver your requests including managing payments, fees, and charges.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>To manage our relationship with you which will include notifying you about changes to our terms or privacy policy.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>To administer and protect our business and this app.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>To deliver relevant app content and advertisements to you and measure the effectiveness of advertising.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>To use data analytics to improve our app, products/services, marketing, customer relationships, and experiences.</span></li>
              </ul>
            </section>

            {/* Section 5 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">5</span>
                Data Security
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used, or accessed in an unauthorized way, altered, or disclosed. In addition, we limit access to your personal data to those employees, agents, contractors, and other third parties who have a business need to know.
              </p>
              <div className="p-3 rounded-lg bg-primary/10 border border-primary/30">
                <p className="text-xs text-primary">
                  <strong>Note on Blockchain:</strong> Please be aware that if TR3NDING BLOCK utilizes public blockchain technology, certain transaction data (like wallet addresses and transaction history) is public by nature and cannot be deleted or altered by us.
                </p>
              </div>
            </section>

            {/* Section 6 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">6</span>
                Data Retention
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We will only retain your personal data for as long as necessary to fulfill the purposes we collected it for, including for the purposes of satisfying any legal, accounting, or reporting requirements.
              </p>
            </section>

            {/* Section 7 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">7</span>
                Your Legal Rights
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Under certain circumstances, you have rights under data protection laws in relation to your personal data:
              </p>
              <ul className="text-sm text-muted-foreground space-y-1 pl-4">
                <li className="flex gap-2"><span className="text-primary">•</span><span>Request access to your personal data.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>Request correction of your personal data.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>Request erasure of your personal data.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>Object to processing of your personal data.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>Request restriction of processing your personal data.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>Request transfer of your personal data.</span></li>
                <li className="flex gap-2"><span className="text-primary">•</span><span>Right to withdraw consent.</span></li>
              </ul>
            </section>

            {/* Section 8 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">8</span>
                International Transfers
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We may share your personal data within the TR3NDING BLOCK group. This may involve transferring your data outside your home country. Whenever we transfer your personal data, we ensure a similar degree of protection is afforded to it.
              </p>
            </section>

            {/* Section 9 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">9</span>
                Contact Details
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                If you have any questions about this privacy policy or our privacy practices, please contact us:
              </p>
              <div className="p-4 rounded-lg bg-secondary space-y-2">
                <p className="text-sm text-foreground font-medium">TR3NDING BLOCK LTD</p>
                <p className="text-sm text-muted-foreground">Email: trendingblock3@gmail.com</p>
                <p className="text-sm text-muted-foreground">In-App Support: Settings → Help → Contact Us</p>
              </div>
            </section>

            {/* Section 10 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">10</span>
                Contact Us & Formal Inquiries
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                At TR3NDING BLOCK, we believe in open communication and transparency.
              </p>
              
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-secondary">
                  <p className="text-xs font-semibold text-foreground mb-1">General Inquiries</p>
                  <p className="text-xs text-muted-foreground">Email: trendingblock3@gmail.com</p>
                  <p className="text-xs text-muted-foreground">Response time: 48-72 business hours</p>
                </div>
                
                <div className="p-3 rounded-lg bg-secondary">
                  <p className="text-xs font-semibold text-foreground mb-1">Data Protection Officer</p>
                  <p className="text-xs text-muted-foreground">Email: privacy@tr3ndingblock.com</p>
                  <p className="text-xs text-muted-foreground">Subject: "LEGAL PRIVACY INQUIRY - [Your Username]"</p>
                </div>

                <div className="p-3 rounded-lg bg-secondary">
                  <p className="text-xs font-semibold text-foreground mb-1">Security Vulnerabilities</p>
                  <p className="text-xs text-muted-foreground">Email: security@tr3ndingblock.com</p>
                </div>
              </div>
            </section>

            {/* Section 11 */}
            <section className="space-y-3">
              <h3 className="font-display text-lg text-foreground flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-sm text-primary">11</span>
                Supervisory Authorities
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                If you are a resident of the European Economic Area (EEA) or the United Kingdom, you have the right to make a complaint at any time to the relevant data protection supervisory authority. We would, however, appreciate the chance to deal with your concerns before you approach the authority, so please contact us in the first instance.
              </p>
            </section>

            {/* Footer Note */}
            <div className="pt-6 border-t border-border text-center">
              <p className="text-xs text-muted-foreground">
                © 2026 TR3NDING BLOCK LTD. All rights reserved.
              </p>
            </div>
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <button
            onClick={onClose}
            className="w-full btn-gold py-3"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
