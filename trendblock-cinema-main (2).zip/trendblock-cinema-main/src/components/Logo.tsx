import logoImage from '@/assets/logo.jpg';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

const sizeClasses = {
  sm: 'w-8 h-8',
  md: 'w-10 h-10',
  lg: 'w-16 h-16',
  xl: 'w-24 h-24',
};

export const Logo = ({ size = 'md', showText = true, className = '' }: LogoProps) => {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className={`${sizeClasses[size]} rounded-xl overflow-hidden gold-glow`}>
        <img 
          src={logoImage} 
          alt="TR3NDING BLOCK" 
          className="w-full h-full object-cover"
        />
      </div>
      {showText && (
        <span className="font-display text-xl tracking-wider text-foreground">
          TR3NDING BLOCK
        </span>
      )}
    </div>
  );
};
